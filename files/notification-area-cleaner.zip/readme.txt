Notification Area Cleaner Tool v1.0
==================================================================
Copyright � 2010 Igor Tolmachev, IT Samples.
http://www.itsamples.com
All Rights Reserved.
==================================================================

Notification Area Cleaner allows you to remove obsolete notification
area icons in Windows 7 (i.e. icons for programs that are no longer
installed) which appear in the list icons for which you can change the 
notification area behavior. Running this tool will basically reset 
all your notification area icons and keep only your active ones. 

To remove the notification area icon cache and restart explorer.exe,
double click the downloaded file.

If you encounter a problem while running this utility,
please record all the information and send it to:
support@itsamples.com